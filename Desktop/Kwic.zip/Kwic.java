/********************************************************************
 *  Program:          KWIC
 *  Programmer:       Dan Modesto
 *  Purpose:          Creates an applet to provide the ui.
 *  File              Kwic.java
 *  Date:             9/23/2013
********************************************************************/

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class Kwic extends Applet 
        implements ActionListener {

/*
<APPLET
    CODE=Kwic.class
    WIDTH=800
    HEIGHT=300 >
    <PARAM NAME=threadPoolSize VALUE="4">
</APPLET>
*/

    // create the kwic index components
    OutputComponent output = new OutputComponent(this);
    MergerComponent merger;
    AlphabetizerComponent alpha;
    ShifterComponent shifter;
    InputComponent input;

    // create the text input, submit button, and print button
    TextField   txtInput;
    Button      btnSubmit;
    Button      btnPrint;

    // create the output textareas
    TextArea    txtOriginal;
    TextArea    txtCirShift;
    TextArea    txtMerged;

    int intPoolSize;

    // setup the input UI
    @Override
    public void init() {
        String strParam = getParameter("threadPoolSize");

        if (!strParam.equals(""))
        {
            intPoolSize = Integer.parseInt(strParam);
        }
        else
        {
            intPoolSize = 1;
        }
        
        merger = new MergerComponent(output, intPoolSize);
        alpha = new AlphabetizerComponent(merger, intPoolSize);
        shifter = new ShifterComponent(alpha, output, intPoolSize);
        input = new InputComponent(shifter, output, intPoolSize);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        setLayout(gridbag);
        constraints.weighty = 1;
        constraints.fill = GridBagConstraints.NONE;
        constraints.weightx = 2;

        // display the input field
        txtInput = new TextField(75);
        gridbag.setConstraints(txtInput, constraints);
        add(txtInput);

        // display the submit button
        constraints.weightx = 1;
        btnSubmit = new Button("Submit");
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(btnSubmit, constraints);
        add(btnSubmit);
        btnSubmit.addActionListener(this);
/*
        // display the print button
        constraints.weightx = 1;
        btnPrint = new Button("Print");
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(btnSubmit, constraints);
        add(btnPrint);
        btnPrint.addActionListener(this);
*/
        // display the Original lines
        constraints.fill = GridBagConstraints.BOTH;
        txtOriginal = new TextArea("", 5, 20);
        gridbag.setConstraints(txtOriginal, constraints);
        add(txtOriginal);

        // display the Circular Shifted lines
        txtCirShift = new TextArea("", 5, 20);
        gridbag.setConstraints(txtCirShift, constraints);
        add(txtCirShift);

        // display the Indexed lines
        txtMerged = new TextArea("", 5, 20);
        gridbag.setConstraints(txtMerged, constraints);
        add(txtMerged);
    }

    // Interface - event handler to catch the submit button click event
    public void actionPerformed(ActionEvent event) {
        if(event.getSource() == btnSubmit) {
            if(!txtInput.getText().equals(""))
            {
                input.processData(txtInput.getText());
            }

/******  Test Lines
            input.processData("In computer science pattern matching is the act of checking a perceived sequence of");
            input.processData("tokens for the presence of the constituents of some pattern");
            input.processData("In contrast to pattern recognition the match usually has to be exact");
            input.processData("The patterns generally have the form of either sequences or tree structures");
            input.processData("Uses of pattern matching include outputting the locations");
            input.processData("if any of a pattern within a token sequence");
            input.processData("to output some component of the matched pattern");
            input.processData("and to substitute the matching pattern with some other token sequence");
            input.processData("In computer science pattern matching is the act of checking a perceived sequence of");
            input.processData("tokens for the presence of the constituents of some pattern");
            input.processData("In contrast to pattern recognition the match usually has to be exact");
            input.processData("The patterns generally have the form of either sequences or tree structures");
            input.processData("Uses of pattern matching include outputting the locations");
            input.processData("if any of a pattern within a token sequence");
            input.processData("to output some component of the matched pattern");
            input.processData("and to substitute the matching pattern with some other token sequence");
************/
            
            // reset the input
            txtInput.setText(null);
        }

        if(event.getSource() == btnPrint) {
            output.printIndex();
        }
    }

    // display the lines within the appropriate output window
    public void display(int i, String s)
    {
        switch(i) {
            case 1:
                txtOriginal.append(s + "\n");
            break;
            case 2:
                txtCirShift.append(s + "\n");
            break;
            case 3:
                txtMerged.append(s + "\n");
            break;
        }
    }

    // clear the requested output window
    public void clearOutput(int i)
    {
        switch(i) {
            case 1:
                txtOriginal.setText(null);
            break;
            case 2:
                txtCirShift.setText(null);
            break;
            case 3:
                txtMerged.setText(null);
            break;
        }
    }

    // add a new line to the requested output window
    public void addNewLine(int i)
    {
        switch(i) {
            case 1:
                txtOriginal.append("\n");
            break;
            case 2:
                txtCirShift.append("\n");
            break;
            case 3:
                txtMerged.append("\n");
            break;
        }
    }
}
