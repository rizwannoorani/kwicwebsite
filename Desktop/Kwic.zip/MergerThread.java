/********************************************************************
 *  Program:          KWIC
 *  Programmer:       Dan Modesto
 *  Purpose:          Thread to merge multiple input lines.
 *  File              MergerThread.java
 *  Date:             10/07/2013
********************************************************************/

public class MergerThread implements Runnable
{
    static int intThreadCount = 0;
    int intThreadID;
    private MergerComponent MC;
    private OutputComponent outputRef;
    private LinkedQueue queSortedLines1;
    private LinkedQueue queSortedLines2;

    // Create a MergerThread with the MergerComponent reference
    public MergerThread(MergerComponent mc, OutputComponent o)
    {
        intThreadID = ++intThreadCount;
        MC = mc;
        outputRef = o;
    }

    // Interface - merge the lines from the alphabetizer
    public void run()
    {
        // the deque here will impact the input queue
        // owned by the MergerComponent
        queSortedLines1 = MC.dequeue();
        queSortedLines2 = MC.dequeue();

        // create a queue to store the sorted results
        LinkedQueue queResultQueue=new LinkedQueue();

        // set the result queue equal to the sorted lines
        MergeSort.merge(queSortedLines1, queSortedLines2,  queResultQueue);

/**************** begin debugging output *********************/
        System.out.println("Merger thread: " + intThreadID);
/**************** end debugging output ***********************/

        // tell the MergerComponent that the process is done
        MC.mergeComplete(queResultQueue);
        queResultQueue = null;
    }
}