/********************************************************************
 *  Program:          KWIC
 *  Programmer:       Dan Modesto
 *  Purpose:          Interface to enforce the implementation of
 *                      processData();
 *  File:             ShifterInterface.java
 *  Date:             9/24/2013
********************************************************************/

public interface ShifterInterface
{
    void processData(Line l);
}