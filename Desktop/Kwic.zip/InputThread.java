/********************************************************************
 *  Program:          KWIC
 *  Programmer:       Dan Modesto
 *  Purpose:          Thread to accept lines.
 *  File              InputThread.java
 *  Date:             10/07/2013
********************************************************************/

public class InputThread implements Runnable
{
    static int intThreadCount = 0;
    int intThreadID;
    private InputComponent IC;

    // Create an InputThread with the InputComponent reference
    public InputThread(InputComponent ic)
    {
        intThreadID = ++intThreadCount;
        IC = ic;
    }

    // Interface - set the line for the Input
    public void run()
    {
        // the deque here will impact the input queue
        // owned by the InputComponent
        Line lneInput = new Line(IC.dequeue(), true);

        LinkedQueue queTemp = new LinkedQueue();
        queTemp.enqueue(lneInput);

/**************** begin debugging output *********************/
        System.out.println("Input thread: " + intThreadID);
/**************** end debugging output ***********************/

        // tell the InputComponent that the process is done
        IC.processComplete(queTemp);
    }
}