/********************************************************************
 *  Program:          KWIC
 *  Programmer:       Dan Modesto
 *  Purpose:          Thread to shift lines.
 *  File              ShifterThread.java
 *  Date:             10/07/2013
********************************************************************/

public class ShifterThread implements Runnable
{
    static int intThreadCount = 0;
    int intThreadID;
    private ShifterComponent SC;
    private LinkedQueue queShiftedLines;

    // Create a ShifterThread with the ShifterComponent reference
    public ShifterThread(ShifterComponent sc)
    {
        intThreadID = ++intThreadCount;
        SC = sc;
    }

    // Interface - shift the words from the input line
    public void run()
    {
        // the deque here will impact the input queue
        // owned by the ShifterComponent
        Line ln = SC.dequeue();

        String strTemp = new String();
        LinkedQueue queTemp = ln.getWordQueue();

        // set this line to be the original by setting the 2nd param to true
        Line lnNew = new Line(queTemp.toString(), true);

        // queShiftedLines contains lines
        queShiftedLines = new LinkedQueue();

        // store the original line
        queShiftedLines.enqueue(lnNew);

        // cycle through the words and save new lines
        for (int i=0; i<queTemp.getSize()-1; i++) {
            strTemp=(String)queTemp.dequeue();
            queTemp.enqueue(strTemp);
            lnNew = new Line(queTemp.toString());
            queShiftedLines.enqueue(lnNew);
        }

/**************** begin debugging output *********************/
        System.out.println("Shifter thread: " + intThreadID);
/**************** end debugging output ***********************/

        // tell the ShifterComponent that the process is done
        SC.processComplete(queShiftedLines);
    }
}